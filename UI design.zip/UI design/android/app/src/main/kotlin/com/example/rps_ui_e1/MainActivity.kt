package com.example.rps_ui_e1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
