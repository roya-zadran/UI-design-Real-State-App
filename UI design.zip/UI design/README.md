# Design 1 - Flutter UI Collection

![Capture](https://github.com/retroportalstudio/rps_ui_collection/blob/main/rps_ui_e1/episode_1_design.jpg)

# Inspired From:

https://www.instagram.com/p/CCa_uesgkK8/

## Packages Used

```sh
intl: ^0.16.1
```
